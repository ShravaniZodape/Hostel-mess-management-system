<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h2>Login</h2>
        <?php
        if (isset($_POST["login"])) {
           // Get inputs from POST
           $student_id = $_POST["student_id"];
           $password = $_POST["password"];

            // Database connection
            require_once "database.php";
            
            // Prepared statement
            $sql = "SELECT * FROM student_credentials WHERE student_id = ?";

            // Prepare statement
            $stmt = mysqli_prepare($conn, $sql);

            // Bind parameters
            mysqli_stmt_bind_param($stmt, "i", $student_id);

            // Execute statement
            mysqli_stmt_execute($stmt);

            // Get result
            $result = mysqli_stmt_get_result($stmt);

            // Fetch user
            $user = mysqli_fetch_assoc($result);

            if ($user) {
                // Verify password
                if (password_verify($password, $user["password"])) {
                    // Start session and redirect
                    session_start();
                    $_SESSION["user"] = "yes";
                    header("Location: index.php");
                    exit(); // Exit after redirect
                } else {
                    echo "<div class='alert alert-danger'>Password does not match</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Student ID does not exist</div>";
            }

            // Close statement
            mysqli_stmt_close($stmt);
            // Close connection
            mysqli_close($conn);
        }
        ?>
      <form action="login.php" method="post">
        <div class="form-group">
            <input type="text" placeholder="Enter Student ID:" name="student_id" class="form-control">
        </div>
        <div class="form-group">
            <input type="password" placeholder="Enter Password:" name="password" class="form-control">
        </div>
        <div class="form-btn">
            <input type="submit" value="Login" name="login" class="btn btn-primary">
        </div>
      </form>
     <div><p>Not registered yet <a href="registration.php">Register Here</a></p></div>
    </div>
</body>
</html>
