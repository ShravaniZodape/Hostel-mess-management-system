<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
   exit(); // It's good practice to exit after redirecting
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <h2>Register</h2>
        <?php
        if (isset($_POST["submit"])) {
            // Retrieve form data
            $student_id = $_POST["student_id"];
            $password = $_POST["password"];
            $passwordRepeat = $_POST["repeat_password"];
            
            // Initialize errors array
            $errors = array();
            
            // Check for empty fields
            if (empty($student_id) || empty($password) || empty($passwordRepeat)) {
                array_push($errors, "All fields are required");
            }

            // Check password length
            if (strlen($password) < 8) {
                array_push($errors, "Password must be at least 8 characters long");
            }

            // Check if passwords match
            if ($password !== $passwordRepeat) {
                array_push($errors, "Passwords do not match");
            }

            // Include database connection file
            require_once "database.php";

            // Check if student_id already exists
            $sql = "SELECT * FROM student_credentials WHERE student_id = ?";
            $stmt = mysqli_stmt_init($conn);
            if (!mysqli_stmt_prepare($stmt, $sql)) {
                die("SQL statement failed");
            } else {
                mysqli_stmt_bind_param($stmt, "i", $student_id); // Bind parameter to the query
                mysqli_stmt_execute($stmt);
                mysqli_stmt_store_result($stmt);
                $rowCount = mysqli_stmt_num_rows($stmt);
                if ($rowCount > 0) {
                    array_push($errors, "Student ID already exists");
                } else {
                    // Insert data into database
                    $sql = "INSERT INTO student_credentials (student_id, password) VALUES (?, ?)";
                    $stmt = mysqli_stmt_init($conn);
                    if (!mysqli_stmt_prepare($stmt, $sql)) {
                        die("SQL statement failed");
                    } else {
                        // Hash the password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        mysqli_stmt_bind_param($stmt, "is", $student_id, $hashed_password);
                        mysqli_stmt_execute($stmt);
                        echo "<div class='alert alert-success'>You are registered successfully.</div>";
                    }
                }
            }

            // Display errors
            if (count($errors) > 0) {
                foreach ($errors as $error) {
                    echo "<div class='alert alert-danger'>$error</div>";
                }
            }

            mysqli_stmt_close($stmt);
            mysqli_close($conn);
        }
        ?>
        <form action="registration.php" method="post">
            <div class="form-group">
                <input type="text" class="form-control" name="student_id" placeholder="Student ID:">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password:">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="repeat_password" placeholder="Repeat Password:">
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Register" name="submit">
            </div>
        </form>
        <div>
        <div><p>Already Registered <a href="login.php">Login Here</a></p></div>
      </div>
    </div>
</body>
</html>
